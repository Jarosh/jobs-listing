'use strict';

angular.module('AppUI').constant('config', {
    host: {
        api: 'http://vcoolas.com:9000'
    }
});
